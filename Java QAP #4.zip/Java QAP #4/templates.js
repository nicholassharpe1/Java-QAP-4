const custName = 'John Smith';
const birthDate = '1965-03-04';
const gender = 'Male';
const roomPreferences = 'King Bedroom';
const paymentMethod = 'credit card';
const mailingAddress = 'John Smith 123 Street St St. Johns, NL X1X 3L6';
const phoneNumber = '(999) 999 - 9999';
const checkinDate = '2024-04-04';
const checkoutDate = '2024-04-08';
const objecttemp1 = {
  byear: '1965',
  getAge: function(){
  const today = new Date();
  return today.getFullYear() - this.byear;
  }
};
const objecttemp2 = {
  checkoutdaynum: '8',
  checkindaynum: '4',
  getAge: function(){
  
  return this.checkoutdaynum - this.checkindaynum;
  }
};



let aString1;
let html;
let p1;
p1 = objecttemp1.getAge();
let p2;
p2 = objecttemp2.getAge();

let checkind = new Date ('04/04/2024');
let checkoutd = new Date ('04/08/2024');

let Difference_In_T =
    checkoutd.getTime() - checkind.getTime()

let durationofstay =
    Math.round
    (Difference_In_T / (1000 * 3600 * 24));



aString1 = `The customer's name is ${custName}. This customer was born on ${birthDate}. The customer's gender is ${gender}. This customer will be staying in a ${roomPreferences}. They will be using ${paymentMethod} to pay. This customer's mailing address is ${mailingAddress}. There phone number is ${phoneNumber}. They checked in on ${checkinDate}. The customer then checked out on ${checkoutDate}. They are ${p1} years old. This cutomer stayed at the Rooms motel for ${durationofstay} days.`;
 
console.log(aString1);


html = `
  <p> 
  The customer's name is ${custName}. This customer was born on ${birthDate}. The customer's gender is ${gender}. This customer will be staying in a ${roomPreferences}. They will be using ${paymentMethod} to pay. This customer's mailing address is ${mailingAddress}. There phone number is ${phoneNumber}. They checked in on ${checkinDate}. The customer then checked out on ${checkoutDate}. They are ${p1} years old. This cutomer stayed at the Rooms motel for ${durationofstay} days.
  </p>
`;

document.body.innerHTML = html;