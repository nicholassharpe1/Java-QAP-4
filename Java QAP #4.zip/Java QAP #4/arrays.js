const Motelcustomer = ['Customer name: John Smith', 'Birth date: 1965-03-04', 'Gender: Male', 'Room preferences: King Bedroom'];
console.log(Motelcustomer);