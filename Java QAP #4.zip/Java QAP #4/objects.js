const subobject1 = {
    PaymentInfo: {
        PaymentMethod: 'Credit card',
        MailingAddress: 'John Smith 12 Street St. St. Johns, NL X1X 3L6',
    }
};

console.log(subobject1);

const subobject2 = {
    HotelStayInfo: {
        PhoneNumber: '(999) 999 - 9999',
        CheckInDate: '2024-04-04',
        CheckOutDate: '2024-04-08',
    }
};

console.log(subobject2);



const object1 = {
    byear: '1965',
    getAge: function(){
    const today = new Date();
    return today.getFullYear() - this.byear;
    }
};

let peeps1;
peeps1 = object1.getAge();


let checkindate = new Date ('04/04/2024');
let checkoutdate = new Date ('04/08/2024');

let Difference_In_Time =
    checkoutdate.getTime() - checkindate.getTime()

let object2 =
    Math.round
    (Difference_In_Time / (1000 * 3600 * 24));


const firstobject = {
    Age: peeps1,
    DurationofStay: object2,
}

console.log(firstobject)

const secondobject = {
    MotelName: 'The Rooms Motel',
    MotelAddress: '123 Popular St. Toronto, ON',
    MotelPhoneNumber: '(999) 999-9999',
}

console.log(secondobject)




